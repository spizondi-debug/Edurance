Put these three files from the live EduRance site in this folder:
  edurance-logo.png
  edurance-mark.png
  edurance-explainer.mp4
The page still works without them (the logo falls back to text).
